package com.example.tomaszczubocha.cw_4_2;

import java.io.Serializable;

/**
 * Created by Tomasz Czubocha on 23.04.2016.
 */
public class Urzadzenie implements Serializable {
}
